export class ContactUs {
  constructor(
    public fullname?: string,
    public email?: string,
    public subject?: string,
    public message?: string
  ) {}
}
