import { ContactUs } from './contact-us';

describe('ContactUs', () => {
  it('should create an instance', () => {
    expect(new ContactUs()).toBeTruthy();
  });
});
